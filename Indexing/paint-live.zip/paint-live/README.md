### Satori Paint

This is a simple example of a white board collaboration tool that can be built on top of the Satori Platform. This 
application is a great example of publishing, subscribing, and using filters.

### Getting Started

Visit the [Satori Developer portal](https://developer.satori.com) and sign up for an account. Once you have activated your account, you can create
a project. When a project is created you will receive and App key and Endpoint.

#### Add your Appkey
To start using your appkey, open the `.env` fill out the needed variables
```
REACT_APP_APP_KEY=
REACT_APP_CHANNEL=
REACT_APP_ENDPOINT=

```


```
npm install
npm run start 
```
or 

```javascript
yarn install
yarn start

```

