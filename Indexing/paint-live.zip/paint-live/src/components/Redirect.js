import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import id from 'shortid';

export default class RedirectComponent extends Component {
  constructor(props) {
    super();

    this.id = id.generate();
  }

  shouldComponentUpdate(nextProps, nextState, nextContext) {
    return false;
  }

  render() {
    return (
      <Redirect to={`/${this.id}`} />
    );
  }
}
