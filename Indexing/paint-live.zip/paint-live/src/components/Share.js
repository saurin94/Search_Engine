import React, { Component } from 'react';
import Clipboard from 'clipboard';
import { Overlay } from 'react-overlays';

function ShareBody(props) {
  return (
    <div className="overlay" style={{
      top: props.positionTop,
      left: props.positionLeft,
    }}
    >
      <div className="overlay-arrow" />
      <div className="overlay-title">
        <h1>Invite a friend</h1>
        <div
          className="overlay-close"
          onClick={props.onClose}
        />
      </div>
      <div className="overlay-body">
        <p className="sub-heading">
          Share this URL with anyone that you want to join
        </p>
        <h2 className="sub-heading">{window.location.href}</h2>
        <button
          className="btn"
          data-clipboard-text={window.location.href}
        >
          {props.copied ? 'Copied' : 'Copy Link'}
        </button>
      </div>
    </div>
  )
}

class Share extends Component {
  constructor(props) {
    super();

    this.state = {
      copied: false,
    };
  }

  componentDidMount() {
    const clip = new Clipboard('.btn');

    clip.on('success', () => {
      this.setState({ copied: true });

      setTimeout(() => {
        this.setState({ copied: false })
      }, 500);
    })
  }

  static defaultProps = {};

  static propTypes = {};

  render() {
    const visible = this.props.visible;

    return (
      <Overlay
        show={visible}
        target={this.props.target}
        placement={this.props.placement}
        rootClose
        onHide={this.props.onClose}
      >
        <ShareBody
          onClose={this.props.onClose}
          copied={this.state.copied}
        />
      </Overlay>
    );
  }
}

export default Share;
