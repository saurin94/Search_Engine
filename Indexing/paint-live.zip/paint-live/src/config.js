export default {
  appKey: process.env.REACT_APP_APP_KEY,
  channel: process.env.REACT_APP_CHANNEL,
  endpoint: process.env.REACT_APP_ENDPOINT,
  role: process.env.REACT_APP_ROLE,
  roleKey: process.env.REACT_APP_ROLE_KEY
}
