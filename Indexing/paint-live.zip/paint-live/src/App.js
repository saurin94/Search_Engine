import './App.css';
import Controls from './components/Controls';
import jsCookie from 'js-cookie';
import React, { PureComponent } from 'react';
import SatoriLogo from './resources/SatoriLogo.svg';
import uuid from 'uuid';
import Whiteboard from './components/Whiteboard';
import { publish } from './lib/rtm';

const USER_CACHE_PREFIX = 'satori-demo-user';
const ERASER_COLOR = 'rgb(233, 233, 233)';
const DEFAULT_COLOR = '#FF5400';
const DEFAULT_STROKE = 4;

class App extends PureComponent {
  constructor(props, context) {
    super(props, context);
    this.state = {
      buttonPressed: false,
      color: DEFAULT_COLOR,
      dropdownVisible: false,
      showAvatarPicker: false,
      showParticipantList: false,
      stroke: DEFAULT_STROKE,
      user: null,
      x: 0,
      y: 0,
    };

    this.handleDropDown = this.handleDropDown.bind(this);
    this.handleResetCanvas = this.handleResetCanvas.bind(this);
    this.handleSetColor = this.handleSetColor.bind(this);
    this.handleSetEraser = this.handleSetEraser.bind(this);
    this.handleSetStroke = this.handleSetStroke.bind(this);
    this.handleSetUser = this.handleSetUser.bind(this);
    this.handleShowParticipantList = this.handleShowParticipantList.bind(this);
  }

  static saveUserToCookie(user) {
    jsCookie.set(USER_CACHE_PREFIX, user);
  }

  getUserFromCookie() {
    try {
      return JSON.parse(jsCookie.get(USER_CACHE_PREFIX));
    } catch (e) {
      this.setState({ showAvatarPicker: true });
    }
  }

  static isMobile() {
    return (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent));
  }

  componentDidMount() {
    const user = this.getUserFromCookie();

    if (!user || !user.name) {
      // return this.setState({ showAvatarPicker: true });
      return this.handleSetUser({ name: 'default' }, false);
    }

    this.handleSetUser(user, false);
  }

  handleDropDown() {
    this.setState({
      dropdownVisible: !this.state.dropdownVisible
    });
  }

  handleSetUser(user, saveUser = true) {
    if (!user || user.name.length === 0) {
      return;
    }

    if (!user.id) {
      user.id = uuid();
    }

    if (user.avatar && typeof user.avatar !== 'object') {
      user.avatar = { avatar: user.avatar, color: user.color };
    }

    if (saveUser) {
      App.saveUserToCookie(user);
    }

    this.setState({ user, showAvatarPicker: false });
  }

  handleShowParticipantList() {
    this.setState({ showParticipantList: !this.state.showParticipantList })
  }

  handleMouseDown(event) {
    event.preventDefault();

    const action = {
      buttonPressed: true,
      x: App.isMobile() ? event.targetTouches[0].pageX : event.clientX,
      y: App.isMobile() ? event.targetTouches[0].pageY : event.clientY,
      color: this.state.color,
      stroke: this.state.stroke,
    };

    // Publish the mouse down event with starting coords
    this.publishAndSet(action);
  }

  handleMouseMove(event) {
    event.preventDefault();

    if (this.state.buttonPressed) {
      const action = {
        buttonPressed: true,
        x: App.isMobile() ? event.targetTouches[0].pageX : event.clientX,
        y: App.isMobile() ? event.targetTouches[0].pageY : event.clientY,
      };

      // Publish the drawing coords
      this.publishAndSet(action);
    }
  }

  handleMouseUp() {
    const action = {
      buttonPressed: false
    };

    this.publishAndSet(action)
  }

  handleSetColor(color) {
    this.publishAndSet({ color: color });
  }

  handleSetStroke(stroke) {
    this.publishAndSet({
      stroke: stroke,
      dropdownVisible: !this.state.dropdownVisible
    });
  }

  handleSetEraser() {
    this.publishAndSet({ color: ERASER_COLOR });
  }

  handleResetCanvas() {
    publish({ clearCanvas: true, id: this.props.match.params.id });
  }

  publishAndSet(action) {
    const newState = Object.assign(
      {},
      this.state,
      action,
      { id: this.props.match.params.id }
    );

    publish(newState);
    this.setState(newState);
  }

  render() {
    return (
      <div className="App-overlay">
        <div className="App">
          <div className="App-header">
            <img src={SatoriLogo} alt="" />
            <div className="App-links">
              <button
                className="hamburger"
                onClick={this.handleShowParticipantList}
              >
                <div className="hamburger-line" />
                <div className="hamburger-line" />
                <div className="hamburger-line" />
              </button>
            </div>
          </div>
          <div id="App-main">
            <div className="App-content">
              <Controls
                color={this.state.color}
                dropdownVisible={false}
                stroke={this.state.stroke}
                handleDropDown={this.handleDropDown}
                handleResetCanvas={this.handleResetCanvas}
                handleSetColor={this.handleSetColor}
                handleSetEraser={this.handleSetEraser}
                handleSetStroke={this.handleSetStroke}
                showDropDown={this.state.dropdownVisible}
              />

              <Whiteboard
                color={this.state.color}
                eraserColor={ERASER_COLOR}
                drawing={this.state.buttonPressed}
                height={400}
                id={this.props.match.params.id}
                showParticipantList={this.state.showParticipantList}
                onMouseDown={this.handleMouseDown.bind(this)}
                onMouseMove={this.handleMouseMove.bind(this)}
                onMouseUp={this.handleMouseUp.bind(this)}
                onTouchMove={this.handleMouseMove.bind(this)}
                onTouchStart={this.handleMouseDown.bind(this)}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
