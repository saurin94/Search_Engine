import React from 'react';
import { shallow, mount } from 'enzyme';
import App from './App';
import Controls from './components/Controls';
// import cache from 'lscache';
import * as rtmHandler from './lib/rtm';

let wrapper;
let SatoriMock;

beforeAll(() => {
  // Polyfill RFA
  (function () {
    var lastTime = 0;
    var vendors = ['ms', 'moz', 'webkit', 'o'];
    for (var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
      window.requestAnimationFrame = window[vendors[x] + 'RequestAnimationFrame'];
      window.cancelAnimationFrame = window[vendors[x] + 'CancelAnimationFrame']
        || window[vendors[x] + 'CancelRequestAnimationFrame'];
    }

    if (!window.requestAnimationFrame) {
      window.requestAnimationFrame = function (callback, element) {
        var currTime = new Date().getTime();
        var timeToCall = Math.max(0, 16 - (currTime - lastTime));
        var id = window.setTimeout(function () {
            callback(currTime + timeToCall);
          },
          timeToCall);
        lastTime = currTime + timeToCall;
        return id;
      };
    }

    if (!window.cancelAnimationFrame) {
      window.cancelAnimationFrame = function (id) {
        clearTimeout(id);
      };
    }
  }());
});

beforeEach(() => {
  wrapper = shallow(<App match={{ params: 1 }} />);
  SatoriMock = rtmHandler.publish = jest.fn();
});

test('should detect mobile', () => {
  Object.defineProperty(window.navigator, "userAgent", {
    writable: true,
    value: 'iPhone'
  });

  expect(App.isMobile()).toBe(true);

  window.navigator.userAgent = undefined;
});

test('it should render availble colors', () => {
  const colorCount = Controls.availableColors.length;

  wrapper = shallow(<Controls />);
  const colors = wrapper.find('.color-item');

  expect(colors.length).toEqual(colorCount);
});

test('it should set a color', () => {
  wrapper = mount(<App match={{ params: 1 }} />);
  const colors = wrapper.find('.color-item');

  colors.forEach(item => {
    item.simulate('click');
    expect(wrapper.state('color')).toBe(Controls.availableColors[item.key()]);
  });

  expect(wrapper.find('.color-item .is-active').length).toBe(1);
  expect(SatoriMock.mock.calls.length).toEqual(Controls.availableColors.length);
});

test('it should handle drop-down menu', () => {
  wrapper = mount(<App match={{ params: 1 }} />);

  const strokeSelector = wrapper.find('.stroke-selector');
  strokeSelector.simulate('click');
  expect(wrapper.state('dropdownVisible')).toBe(true);
  expect(wrapper.find('.stroke-dropdown').length).toBe(1);
});

test('it should render the proper amount strokes', () => {
  const strokeSelector = wrapper.find('.stroke-selector');

  strokeSelector.simulate('click');
  const strokes = wrapper.find('.stroke-item');

  expect(strokes.length).toBe(Controls.strokes.length);
});

test('it should handle setting stroke', () => {
  const strokeSelector = wrapper.find('.stroke-selector');
  strokeSelector.simulate('click');
  const stroke = wrapper.find('.stroke-item');
  stroke.last().simulate('click');

  expect(wrapper.state('stroke')).toBe(24);
});

test('it should handle setting the eraser', () => {
  const eraserItem = wrapper.find(('.eraser'));
  eraserItem.simulate('click');

  expect(wrapper.state('color')).toBe('white');
});

test('it should publish reset canvas', () => {
  const reset = wrapper.find('.reset');
  reset.simulate('click');

  expect(SatoriMock).toBeCalledWith({ "clearCanvas": true });
});

// test('it should retrieve state if no cache', () => {
//   const mockState = {
//     dropdownVisible: false,
//     buttonPressed: false,
//     color: 'black',
//     x: 0,
//     y: 0,
//     stroke: 4,
//     uuid: 1,
//   };
//
//   jest.mock('lscache');
//   const state = App.getStateFromLocalStorage(1);
//
//   expect(state).toEqual(mockState);
// });
//
// test('it should retrieve state if cached', () => {
//   const mockState = {
//     dropdownVisible: false,
//     buttonPressed: false,
//     color: 'black',
//     x: 0,
//     y: 0,
//     stroke: 4,
//     uuid: 123,
//   };
//
//   cache.get = jest.fn(() => mockState);
//
//   const state = App.getStateFromLocalStorage(1);
//
//   expect(state).toEqual(mockState);
// });

test('it should handle mouseDown and mouseUp', () => {
  const component = mount(<App match={{ params: 1 }} />);
  const whiteboard = component.find('#whiteboard');
  whiteboard.simulate('mouseDown');

  expect(component.state('buttonPressed')).toBe(true);
  whiteboard.simulate('mouseUp');
  expect(component.state('buttonPressed')).toBe(false);
});

test('it should handle a mouse move', () => {
  SatoriMock = rtmHandler.subscribe = jest.fn();

  const component = mount(<App match={{ params: 1 }} />);
  const whiteboard = component.find('#whiteboard');

  whiteboard.simulate('mouseDown');
  whiteboard.simulate('mouseMove', { clientX: 1, clientY: 1 });

  expect(component.state('buttonPressed')).toBe(true);
  expect(component.state('x')).toBe(1);
  expect(component.state('y')).toBe(1);
});

